/* Color Dll ********************************************************
 *
 * Version:			1.00.00
 * FileName:		color.dll
 * Date Created:	4/04/2002
 *
 * Author:			Soul_Eater
 * Comments:
 *		This is used to bring up a dialog to select colors
 *
 *******************************************************************/
#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>
#include <commdlg.h>


//Global Vars.
HWND mwnd;


int __stdcall Color(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, 
					   BOOL nopause)
{

    CHOOSECOLOR cc;
	static DWORD rgbCurrent;
    static COLORREF clr[16];   
	COLORREF sel;
	sel = atoi(data);

	    
	ZeroMemory(&cc, sizeof(CHOOSECOLOR));
	cc.lStructSize = sizeof( CHOOSECOLOR );
	if (data) {	
	cc.Flags = CC_FULLOPEN | CC_RGBINIT; 
	cc.rgbResult = (COLORREF)sel;
	}
	else { cc.Flags = CC_FULLOPEN; }
    cc.hwndOwner = mWnd; 
    cc.lpCustColors = (LPDWORD) clr;
    


   	if(ChooseColor(&cc) == TRUE)
	{
       	    rgbCurrent = cc.rgbResult; 
          	wsprintf(data,"%d",rgbCurrent);
	     	return 3;
              
			}
	else 
	{
		lstrcpy(data,"$false");
		return 3;
	}
		return 3;
}

int MsgBox(char *data)
{
 int xa = MessageBox (mwnd , data , "Color DLL 1.2" , MB_OK | MB_ICONINFORMATION );
 return 0;
}


int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
   MsgBox("Color DLL 1.2\n �2002 Soul_Eater \nAIM: SoulEata  \nEmail- souleata@beer.com");
   return 0;
}
